# Positive Newsletter

A modern web application for sharing and receiving positive news and inspiring stories.

## Features

- User Authentication (Sign up/Sign in)
- Newsletter Subscription
- Positive News Feed
- Push Notifications for New Stories
- Responsive Design

## Tech Stack

- React
- TypeScript
- Firebase (Authentication, Firestore, Cloud Messaging)
- TailwindCSS
- Vite

## Getting Started

1. Clone the repository
2. Copy `.env.example` to `.env` and fill in your Firebase configuration
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the development server:
   ```bash
   npm run dev
   ```

## Firebase Setup

1. Create a new Firebase project
2. Enable Authentication (Email/Password)
3. Set up Firestore Database
4. Configure Firebase Cloud Messaging
5. Add your Firebase configuration to the `.env` file

## Deployment

This project can be deployed to Vercel or Netlify. Make sure to:

1. Configure environment variables in your hosting platform
2. Set up build command: `npm run build`
3. Set publish directory: `dist`

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.